import tkinter as tk
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import numpy as np
from py3dbp import Packer, Bin, Item

# Box dimensions
BOX_DIMENSIONS = {
    "A": (12, 8.6, 8.8),
    "B": (16.5, 12.5, 8.5),
    "C": (22, 15, 9.3),
    "F": (24.5, 18.5, 13.5)
}

def draw_big_box(ax, w, h, d):
    big_box_vertices = [
        [0, 0, 0],
        [w, 0, 0],
        [w, h, 0],
        [0, h, 0],
        [0, 0, d],
        [w, 0, d],
        [w, h, d],
        [0, h, d]
    ]

    big_box_faces = [
        [big_box_vertices[0], big_box_vertices[1], big_box_vertices[5], big_box_vertices[4]],
        [big_box_vertices[1], big_box_vertices[2], big_box_vertices[6], big_box_vertices[5]],
        [big_box_vertices[2], big_box_vertices[3], big_box_vertices[7], big_box_vertices[6]],
        [big_box_vertices[3], big_box_vertices[0], big_box_vertices[4], big_box_vertices[7]],
        [big_box_vertices[4], big_box_vertices[5], big_box_vertices[6], big_box_vertices[7]]
    ]

    big_box_collection = Poly3DCollection(big_box_faces, edgecolor='k', alpha=0.1)
    ax.add_collection3d(big_box_collection)

def calculate_fit():
    small_box_sizes = []
    holding_box_size = BOX_DIMENSIONS[holding_box_var.get()]
    items = small_box_listbox.get(0, tk.END)

    # Loop through the items
    for item in items:
        
        dimensions = [float(item.split(',')[i]) for i in range(3)]
        print(dimensions)
        small_box_sizes.append(dimensions)
    


    total_volume = sum(x * y * z for x, y, z in small_box_sizes)
    holding_box_volume = holding_box_size[0] * holding_box_size[1] * holding_box_size[2]

    if total_volume <= holding_box_volume:
        result_label.config(text="Boxes fit!")
    else:
        result_label.config(text="Boxes do not fit.")

    """holding_box_size = BOX_DIMENSIONS[holding_box_var.get()]
    small_box_sizes = []

    for entry in small_box_listbox:
        try:
            dimensions = [float(entry.get().split(',')[i]) for i in range(3)]
            small_box_sizes.append(dimensions)
            entry.delete(0, tk.END)  # Clear entry after successful parsing
        except ValueError:
            result_label.config(text="Invalid small box dimensions. Please enter comma-separated values.")
            return

    total_volume = sum(x * y * z for x, y, z in small_box_sizes)
    holding_box_volume = holding_box_size[0] * holding_box_size[1] * holding_box_size[2]

    if total_volume <= holding_box_volume:
        result_label.config(text="Boxes fit!")
    else:
        result_label.config(text="Boxes do not fit.")"""


"""def render_fit():
    # Create a 3D plot
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    holding_box_size = BOX_DIMENSIONS[holding_box_var.get()]

    # Draw the big box
    draw_big_box(ax, holding_box_size[0], holding_box_size[1], holding_box_size[2])
    # Set plot limits
    ax.set_xlim([0, holding_box_size[0]])
    ax.set_ylim([0, holding_box_size[1]])
    ax.set_zlim([0, holding_box_size[2]])

    # Set correct aspect ratio
    ax.set_box_aspect([holding_box_size[0], holding_box_size[1], holding_box_size[2]])

    # Set axis labels
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')

    # Show the plot
    plt.show()"""



# ... (Previous code)

def render_fit():
    # Create a 3D plot
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    holding_box_size = BOX_DIMENSIONS[holding_box_var.get()]

    # Draw the big box
    draw_big_box(ax, holding_box_size[0], holding_box_size[1], holding_box_size[2])

    # Set plot limits
    ax.set_xlim([0, holding_box_size[0]])
    ax.set_ylim([0, holding_box_size[1]])
    ax.set_zlim([0, holding_box_size[2]])

    # Set correct aspect ratio
    ax.set_box_aspect([holding_box_size[0], holding_box_size[1], holding_box_size[2]])

    small_box_sizes = []
    items = small_box_listbox.get(0, tk.END)

    # Loop through the items
    for item in items:
        dimensions = [float(item.split(',')[i]) for i in range(3)]
        small_box_sizes.append(dimensions)

    total_volume = sum(x * y * z for x, y, z in small_box_sizes)
    holding_box_volume = holding_box_size[0] * holding_box_size[1] * holding_box_size[2]

    if total_volume <= holding_box_volume:
        # Create a bin (holding box)
        bin = Bin(holding_box_size[0], holding_box_size[1], holding_box_size[2])

        # Create items (small boxes) and add them to the bin
        items = [Item(idx, w, h, d) for idx, (w, h, d) in enumerate(small_box_sizes)]
        packer = Packer()
        packer.add_bin(bin)
        packer.add_items(items)

        # Perform the packing
        packer.pack()

        # Visualize the packed items
        for packed_bin in packer.bins:
            for packed_item in packed_bin.items:
                # Draw the small box
                small_box_vertices = np.array([
                    [packed_item.position[0], packed_item.position[1], packed_item.position[2]],
                    [packed_item.position[0] + packed_item.width, packed_item.position[1], packed_item.position[2]],
                    [packed_item.position[0] + packed_item.width, packed_item.position[1] + packed_item.height,
                     packed_item.position[2]],
                    [packed_item.position[0], packed_item.position[1] + packed_item.height, packed_item.position[2]],
                    [packed_item.position[0], packed_item.position[1], packed_item.position[2] + packed_item.depth],
                    [packed_item.position[0] + packed_item.width, packed_item.position[1],
                     packed_item.position[2] + packed_item.depth],
                    [packed_item.position[0] + packed_item.width,
                     packed_item.position[1] + packed_item.height, packed_item.position[2] + packed_item.depth],
                    [packed_item.position[0], packed_item.position[1] + packed_item.height,
                     packed_item.position[2] + packed_item.depth]
                ])

                small_box_faces = [
                    [small_box_vertices[0], small_box_vertices[1], small_box_vertices[5], small_box_vertices[4]],
                    [small_box_vertices[1], small_box_vertices[2], small_box_vertices[6], small_box_vertices[5]],
                    [small_box_vertices[2], small_box_vertices[3], small_box_vertices[7], small_box_vertices[6]],
                    [small_box_vertices[3], small_box_vertices[0], small_box_vertices[4], small_box_vertices[7]],
                    [small_box_vertices[4], small_box_vertices[5], small_box_vertices[6], small_box_vertices[7]]
                ]

                colors = plt.cm.get_cmap('tab10', len(items))
                small_box_collection = Poly3DCollection(small_box_faces, edgecolor='k',
                                                        facecolors=[colors(packed_item.idx)], alpha=0.7)
                ax.add_collection3d(small_box_collection)

    else:
        result_label.config(text="Boxes do not fit.")

    # Show the plot
    plt.show()

# ... (Remaining code)











# Initialize the main window
root = tk.Tk()
root.title("Holding Box Size Calculator")

# Label and entry for holding box size
holding_box_label = tk.Label(root, text="Holding Box Size (W,H,D):")
holding_box_label.grid(row=0, column=0)

# Holding box selection
holding_box_var = tk.StringVar(root)
holding_box_var.set("A")  # Set default selection
holding_box_dropdown = tk.OptionMenu(root, holding_box_var, *BOX_DIMENSIONS.keys())
#holding_box_dropdown.pack()
holding_box_dropdown.grid(row=0, column=1)

# Listbox for small box sizes
small_box_listbox = tk.Listbox(root)
small_box_listbox.grid(row=1, columnspan=2)

# Function to add small box size
def add_small_box_size():
    small_box_size = small_box_entry.get()
    small_box_listbox.insert(tk.END, small_box_size)
    small_box_entry.delete(0, tk.END)  # Clear the entry field


def remove_small_box_size():
    selected_indices = small_box_listbox.curselection()
    # Remove the selected items from the Listbox
    for index in reversed(selected_indices):
        small_box_listbox.delete(index)


# Label and entry for small box size
small_box_label = tk.Label(root, text="Small Box Size (W,H,D):")
small_box_label.grid(row=2, column=0)

small_box_entry = tk.Entry(root)
small_box_entry.grid(row=2, column=1)

# Button to add small box size
add_button = tk.Button(root, text="Add Small Box", command=add_small_box_size)
add_button.grid(row=3, column=0)
add_button = tk.Button(root, text="Remove Small Box", command=remove_small_box_size)
add_button.grid(row=3, column=1)


# Calculate button
calculate_button = tk.Button(root, text="Calculate", command=calculate_fit)
calculate_button.grid(row=4, column=0)
calculate_button = tk.Button(root, text="Render", command=render_fit)
calculate_button.grid(row=4, column=1)

# Result label
result_label = tk.Label(root, text="")
result_label.grid(row=5, columnspan=1)

# Run the GUI
root.mainloop()
